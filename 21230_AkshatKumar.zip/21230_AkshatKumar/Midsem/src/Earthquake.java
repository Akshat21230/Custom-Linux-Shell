public class Earthquake {
    private String name;
    private float intensity;

    public Earthquake(String name, float intensity) {
        this.name = name;
        this.intensity = intensity;
    }

    public String toString(){
        return "The name of the Earthquake is: "+this.name + "\n    The intensity of the earthquake is: "+this.intensity;
    }
}
