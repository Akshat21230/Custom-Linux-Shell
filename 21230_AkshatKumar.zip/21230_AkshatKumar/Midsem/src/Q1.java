import java.util.Scanner;

public class Q1 {
    public static void main(String[] args) throws Exception {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter the name of Earthquake: ");
        String name = input.next();
        System.out.println("Enter the intensity of Earthquake: ");
        float intensity = input.nextFloat();
        if(intensity<=8.0 &&     intensity >=2.0){
            Earthquake earthquake = new Earthquake(name, intensity);
            System.out.println(earthquake);
        }
        else{
            throw new Exception("Please enter a valid intensity value in future");
        }

    }
}
