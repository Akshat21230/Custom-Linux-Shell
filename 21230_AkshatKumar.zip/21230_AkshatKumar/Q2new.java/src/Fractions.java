import java.util.Scanner;

public class Fractions {
    Scanner input = new Scanner(System.in);
    private int n1 = input.nextInt();
    private int d1 = input.nextInt();
    private int n2 = input.nextInt();
    private int d2 = input.nextInt();

    public Fractions(int n1, int d1, int n2, int d2) {
        this.n1 = n1;
        this.d1 = d1;
        this.n2 = n2;
        this.d2 = d2;
    }

    public int getN1() {
        return n1;
    }

    public void setN1(int n1) {
        this.n1 = n1;
    }

    public int getD1() {
        return d1;
    }

    public void setD1(int d1) {
        this.d1 = d1;
    }

    public int getN2() {
        return n2;
    }

    public void setN2(int n2) {
        this.n2 = n2;
    }

    public int getD2() {
        return d2;
    }

    public void setD2(int d2) {
        this.d2 = d2;
    }

    public String add2frac(){
        int t = getN1()*getD2() + getN2()*getD1();
        int m = getD1()*getD2();
        String s = t+"/"+m;
        return s;
    }

    public double mul2frac(){
        int t = getN1()/getD1();
        int m = getN2()/getD2();
        return t*m;
    }
}
