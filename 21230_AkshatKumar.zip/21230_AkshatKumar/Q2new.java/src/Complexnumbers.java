import java.util.Scanner;

public class Complexnumbers {
    Scanner input = new Scanner(System.in);
    private int r1 = input.nextInt();
    private int i1 = input.nextInt();
    private int r2 = input.nextInt();
    private int i2 = input.nextInt();

    public int getR1() {
        return r1;
    }

    public void setR1(int r1) {
        this.r1 = r1;
    }

    public int getI1() {
        return i1;
    }

    public void setI1(int i1) {
        this.i1 = i1;
    }

    public int getR2() {
        return r2;
    }

    public void setR2(int r2) {
        this.r2 = r2;
    }

    public int getI2() {
        return i2;
    }

    public void setI2(int i2) {
        this.i2 = i2;
    }

    public Complexnumbers(int r1, int i1, int r2, int i2) {
        this.r1 = r1;
        this.i1 = i1;
        this.r2 = r2;
        this.i2 = i2;
    }

    public String add2com(){
        int t = getR1() + getR2();
        int m = getI1() + getI2();
        String s = t+"+"+m+"i";
        return s;
    }

    public String mult2com(){
        int t = (getR1()*getR2())-(getI2()*getI1());
        int m = (getR1()*getI2()+(getR2()*getI1()));
        String s = t+"+"+m+"i";
        return s;
    }

    public double argument(){
        return Math.atan(getI1()/getR1());
    }

    public double magnitude(){
        return Math.sqrt(getR1()*getR1() + getI1()*getI1());
    }
}
